const { PrismaClient } = require('@prisma/client')

const prisma = new PrismaClient()

async function postUser(email, name=null, password=null) {
  const allUsers = await prisma.users.create({
      data: {
          email: email,
          name: name,
          password: password
      }
  })
  return allUsers
}

async function getUser(email) {
    const allUsers = await prisma.users.findMany()
    return allUsers
  }

getUser("fordltc.net")
  .then((resp)=>{
    console.log(resp)
  })
  .catch((e) => {
    throw e
  })
  .finally(async () => {
    await prisma.$disconnect()
  })